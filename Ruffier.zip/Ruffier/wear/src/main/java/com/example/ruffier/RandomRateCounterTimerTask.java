package com.example.ruffier;

import android.content.Context;
import android.content.Intent;

import com.example.common.Constants;

import java.util.TimerTask;

import static com.example.common.Constants.HEART_RATE_MSG;
import static com.example.common.Constants.HEART_RATE_VALUE;

public class RandomRateCounterTimerTask extends TimerTask {

    public static final String TAG="RandomRateCounterTimerTask";
    private Context ctxt =null;
    private static int rateCount;

    public RandomRateCounterTimerTask(Context ctxt) {
        this.ctxt = ctxt.getApplicationContext();
        rateCount = (int) (Math.random()*200);
        DailyRate.updateRate(rateCount);
    }

    @Override
    public void run() {
        rateCount += (int) (Math.random()*15);
        DailyRate.updateRate(rateCount);
        Intent intent = new Intent();
        intent.setAction(HEART_RATE_MSG);
        intent.putExtra(HEART_RATE_VALUE, DailyRate.getRate());
        ctxt.sendBroadcast(intent);
    }
}
