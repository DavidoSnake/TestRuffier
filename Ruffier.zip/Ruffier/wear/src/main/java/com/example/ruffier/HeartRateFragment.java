package com.example.ruffier;

import android.app.Fragment;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.common.Constants;
import com.example.testruffier.R;

import static com.example.common.Constants.HEART_RATE_MSG;

public class HeartRateFragment extends Fragment {

    private ImageView mImageView;
    TextView tw;
    BroadcastReceiver broadcastReceiver;
    SynchronizeAsyncTasks mSynchronizeAsyncTasks;
    OnFragmentInteractionListener mListener;

    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    String param1;
    String param2;

    Intent rateServiceIntent;

    public static HeartRateFragment newInstance(String param1, String param2) {
        HeartRateFragment fragment = new HeartRateFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_heartrate, container, false);
        mImageView = rootView.findViewById(R.id.image);
        tw = rootView.findViewById(R.id.tw);

        broadcastReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                mSynchronizeAsyncTasks = new SynchronizeAsyncTasks(getActivity());
                int mRate = 56;
                mSynchronizeAsyncTasks.execute(new Integer(mRate));
            }
        };

        rateServiceIntent = new Intent(getActivity(), WearHeartRateService.class);
        tw.setText(rateServiceIntent.getAction());


        return rootView;
        //return super.onCreateView(inflater, container, savedInstanceState);
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            param1 = getArguments().getString(ARG_PARAM1);
            param2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        tw.setText(rateServiceIntent.getAction());
    }

    @Override
    public void onPause() {
        super.onPause();
        tw.setText(rateServiceIntent.getAction());
    }

    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }


    public interface OnFragmentInteractionListener {
        void onFragmentInteraction(Uri uri);
    }
}
