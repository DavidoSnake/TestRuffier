package com.example.ruffier;

import android.content.Intent;
import android.util.Log;

import com.example.common.Constants;

import java.util.Timer;

public class WearHeartRateEmulatorService extends  WearHeartRateService {
    public static final String TAG = "WearRateEmulatorService";
    private static Timer mTimer =null ;

    @Override
    public void onCreate() {
        super.onCreate();
        Log.d(TAG, "onCreate");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (mTimer ==null) {
            mTimer = new Timer();
            long delay =  1000*5;
            long period = 1000*20;
            mTimer.scheduleAtFixedRate(new RandomRateCounterTimerTask(getApplicationContext()), delay, period);
        }
        return super.onStartCommand(intent, flags, startId);
    }

    @Override
    public void onDestroy() {
        mTimer.cancel();
        mTimer = null;
        super.onDestroy();
    }
}