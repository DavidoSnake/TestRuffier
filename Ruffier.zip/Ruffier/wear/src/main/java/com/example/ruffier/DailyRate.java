package com.example.ruffier;

import java.util.Calendar;

public class DailyRate {

    // validity of a measure

    private static Calendar rateDeadLine;
    private static int rate;

    static void updateRate(int rateAdded) {
        if (rateDeadLine.getTime().before(Calendar.getInstance().getTime()) || rateDeadLine == null) {
            System.out.println(rateDeadLine);
            rateDeadLine.setTime(Calendar.getInstance().getTime());
            rateAdded = 0;
        }
        rate += rateAdded;
    }

    static int getRate() {
        return rate;
    }
}
