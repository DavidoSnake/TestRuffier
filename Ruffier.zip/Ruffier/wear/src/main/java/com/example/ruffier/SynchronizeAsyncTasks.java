package com.example.ruffier;

import android.app.Activity;
import android.os.AsyncTask;
import android.provider.ContactsContract;
import android.util.Log;

import com.example.common.Constants;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.wearable.DataClient;
import com.google.android.gms.wearable.DataItem;
import com.google.android.gms.wearable.PutDataMapRequest;
import com.google.android.gms.wearable.PutDataRequest;
import com.google.android.gms.wearable.Wearable;

import static com.example.common.Constants.HEART_RATE_COUNT_PATH;
import static com.example.common.Constants.HEART_RATE_VALUE;

public class SynchronizeAsyncTasks extends AsyncTask<Integer, Integer, Integer> {

    private DataClient mDataClient;

    SynchronizeAsyncTasks(Activity mContext) {
        super();
        mDataClient = Wearable.getDataClient(mContext);
    }

    @Override
    protected Integer doInBackground(Integer... params) {
        int heartRateCount = params[0];
        PutDataMapRequest putDataMapRequest = PutDataMapRequest.create(HEART_RATE_COUNT_PATH);
        putDataMapRequest.getDataMap().putInt(HEART_RATE_VALUE, heartRateCount);
        PutDataRequest putDataReq = putDataMapRequest.asPutDataRequest();
        putDataReq.setUrgent();
        Task<DataItem> putDataTask = mDataClient.putDataItem(putDataReq);
        return -1;
    }
}
