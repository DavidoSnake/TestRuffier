package com.example.ruffier;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.IBinder;
import android.util.Log;

import androidx.annotation.Nullable;

import com.example.common.Constants;

import static androidx.constraintlayout.widget.Constraints.TAG;
import static com.example.common.Constants.HEART_RATE_MSG;
import static com.example.common.Constants.HEART_RATE_VALUE;

public class WearHeartRateService extends Service implements SensorEventListener {

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        Log.d(TAG, "onSensorChanged");
        if (event.sensor.getType() == Sensor.TYPE_HEART_RATE) {
            DailyRate.updateRate((int)event.values[0]);
            sendHeartRateUpdate();
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {
        Log.d(TAG, "onAccuracyChanged");
        sendHeartRateUpdate();
    }

    void sendHeartRateUpdate() {
        Intent intent = new Intent();
        intent.setAction(HEART_RATE_MSG);
        intent.putExtra(HEART_RATE_VALUE, DailyRate.getRate());
        System.out.println(intent);
        sendBroadcast(intent);
    }


    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.d(TAG, "onStart");
        SensorManager sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        assert sensorManager != null;
        Sensor countSensor = sensorManager.getDefaultSensor(Sensor.TYPE_HEART_RATE);
        sensorManager.registerListener(this, countSensor, SensorManager.SENSOR_DELAY_NORMAL);
        return super.onStartCommand(intent, flags, startId);
    }
}
