package com.example.ruffier;

import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.support.wearable.activity.WearableActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;


import com.example.common.Constants;
import com.example.testruffier.R;

public class MainActivityWear extends WearableActivity implements SensorEventListener, HeartRateFragment.OnFragmentInteractionListener {

    TextView mTextView;

    // https://stackoverflow.com/questions/36760344/how-to-read-heart-rate-from-android-wear
    // https://github.com/alejandrocq/HeartRateTest
    //todo : heart rate not working on emulator (no sensors registered)
    private static final String TAG = "MainActivity";
    TextView mTextViewHeart;
    SensorManager mSensorManager;
    Sensor mHeartRateSensor;

    // initialization of a counter
    CountDownTimer timer = new CountDownTimer(30000, 1000) {
        @Override
        public void onTick(long l) {
            String txt = ""+l / 1000;
            mTextView.setText(txt);
        }

        @Override
        public void onFinish() {
            String txt = "Done !";
            mTextView.setText(txt);
        }
    };

    // heart fragment
    Fragment fragment;
    FragmentManager fragmentManager = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mTextView = findViewById(R.id.text);
        mTextViewHeart = findViewById(R.id.rate);

        // hearthrate sensor
       // mSensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
       // assert mSensorManager != null;
       // mHeartRateSensor = mSensorManager.getDefaultSensor(Sensor.TYPE_HEART_RATE);

        // Enables Always-on
        setAmbientEnabled();

        /*
        fm = getSupportFragmentManager();
        fragment = new HomeFragment();
        fm.beginTransaction().replace(R.id.content_main,fragment).commit();
        */

        Button rateView = findViewById(R.id.rateView);
        rateView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // hearth fragment
                fragmentManager = getFragmentManager();
                fragment = new HeartRateFragment();

                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.mainLayout, fragment);
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.commit();
            }
        });
    }

    // attempt to emulate heart rate
    /*  @Override
        protected void onResume() {
            startService(heartRateIntent);
            //wearHearthRateService.sendHeartRateUpdate();
            super.onResume();
        }

        @Override
        protected void onPause() {
            stopService(heartRateIntent);
            super.onPause();
        }*/

    public void startTimer(View view) {
        timer.start();
        // Log.d("msg", Constants.HEART_RATE_MSG);
        // Log.d("value", Constants.HEART_RATE_VALUE);
    }

    ////////////////// HeartRate stuff /////////////////////

    public void startMeasure(View view) {
        boolean sensorRegistered = mSensorManager.registerListener(this, mHeartRateSensor, SensorManager.SENSOR_DELAY_FASTEST);
        Log.d("Sensor Status:", " Sensor registered: " + (sensorRegistered ? "yes" : "no"));
    }

    public void stopMeasure(View view) {
        mSensorManager.unregisterListener(this);
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_HEART_RATE) {
            String msg = "" + (int)event.values[0];
            mTextViewHeart.setText(msg);
            Log.d(TAG, msg);
        }
        else
            Log.d(TAG, "Unknown sensor type");
    }

    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        Log.d(TAG, "onAccuracyChanged - accuracy: " + accuracy);
    }

    @Override
    public void onFragmentInteraction(Uri uri) {

    }

    // https://stackoverflow.com/questions/41673952/onbackpressed-android-fragments
    @Override
    public void onBackPressed() {

        if (fragment != null && fragment.getChildFragmentManager().getBackStackEntryCount() > 0){
            fragment.getChildFragmentManager().popBackStack();
        }else {
            super.onBackPressed();
        }
    }
}

