package com.example.common;

public class Constants {
    public static final String HEART_RATE_VALUE="42";
    public static final String HEART_RATE_MSG="message test";
    public static final String HEART_RATE_COUNT_PATH="/count";
}
